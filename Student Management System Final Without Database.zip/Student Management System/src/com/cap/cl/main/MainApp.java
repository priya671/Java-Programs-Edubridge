package com.cap.cl.main;

/**
 * all copy rights reserved to user priya kothare
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cap.cl.dao.StudentDAOImpl;
import com.cap.cl.pojo.Student;
import com.cap.cl.pojo.User;

public class MainApp {
	public static void main(String[] args){
		StudentInformation studentinformation = new StudentInformation();
		Scanner s = new Scanner(System.in);
		User user = null;
		System.out.println("Welcome to School Management System: ");
		
		String username;
		String password;
		Boolean isLoggedin = false;
		
		//while(true) {
		do {
			System.out.println(" 1.Register\n 2.Login\n 3.Exit");
			System.out.println("Enter your choice: ");
			int choice = s.nextInt();
			s.nextLine();
			switch(choice) {
			case 1:
				//User Registration
				System.out.println("Enter username: ");
				username = s.nextLine();
				System.out.println("Enter password: ");
				password = s.nextLine();
				user = new User(username,password);
				studentinformation.register(username,password);
				System.out.println("**************");
				System.out.println("Registration Successful!");
				System.out.println("**************");
				break;
				
			case 2:
				//User Login after registration
				System.out.println("Enter username: ");
				username = s.nextLine();
				System.out.println("Enter password: ");
				password = s.nextLine();
				try {
					String loggedusername = studentinformation.validateUser(username, password);
					if(loggedusername==null) {
						System.out.println("*********");
						System.out.println("Invalid Credentials! Please Try Again Later");
						System.out.println("*********");
					}
					else {
						isLoggedin = true;
						System.out.println("**********");
						System.out.println("Welcome " + loggedusername);
						System.out.println("**********");
					}
				}catch(NullPointerException e) {
					System.out.println("*********");
					System.out.println("Invalid Credentials! Please try again");
					System.out.println("*********");
				}
				break;
				
			case 3:
				System.out.println("Exiting...");
				System.exit(0);
				
			default: 
				System.out.println("Invalid Choice! Please try again");
				System.out.println("\n");
				break;
			}
		}
		while(!isLoggedin); //Display when not logged in 
		
		//List of already existing students in the database
		//Used arraylist to store the student data
		Student s1 = new Student(11111,"Anushka Joshi","JFS",40000,"Enrolled",2000);
		Student s2 = new Student(20009,"Sayli Patil","AWS",35000,"Re-entering",5000);
		Student s3 = new Student(34567,"Ashutosh Naik","SFT",20000,"Enrolled",0);
		Student s4 = new Student(43989,"Sonali Iyer","WD",25000,"Re-entering",0);
		Student s5 = new Student(53455,"Arjun Kothare","AWS",35000,"Enrolled",1000);
		List<Student> studentinfo = new ArrayList<Student>();
		studentinfo.add(s1);
		studentinfo.add(s2);
		studentinfo.add(s3);
		studentinfo.add(s4);
		studentinfo.add(s5);
		studentinformation.StoreStudent(studentinfo);
		StudentDAOImpl studentdaoimpl = new StudentDAOImpl(studentinformation);
		
		//Display further choices after successful login
		while(isLoggedin=true) {
			System.out.println("1.Enroll new Student");
			System.out.println("2.View Student Balance By Id");
			System.out.println("3.Pay Student Tution fees");
			System.out.println("4.Filter Students Based on Student status");
			System.out.println("5.Get Student Information by ID");
			System.out.println("6.View All the Existing Student Data");
			System.out.println("7.Update any student Data");
			System.out.println("8.Delete any Student Data");
			System.out.println("9.Exit");
			System.out.println("Enter your choice: ");
			int choice = s.nextInt();
			
			switch(choice) {
				case 1:
					studentdaoimpl.enrollStudent();
					break;
				case 2:
					System.out.println("Enter Student Id to view Balance: ");
					int sid = s.nextInt();
					studentdaoimpl.viewStudentBalance(sid);
					break;
				case 3:
					System.out.println("Enter Student Id to pay the tution fees: ");
					int sidtution = s.nextInt();
					studentdaoimpl.payStudentFees(sidtution);
					break;
				case 4:
					System.out.println("Enter Student status: ");
					String sidstatus = s.next();
					studentdaoimpl.filterBasedOnStatus(sidstatus);
					break;
				case 5:
					System.out.println("Enter Student Id to know the student information: ");
					int sidinfo = s.nextInt();
					studentdaoimpl.getStudentInfoById(sidinfo);
					break;
				case 6:
					studentdaoimpl.viewAllStudentData();
					break;
				case 7:
					System.out.println("Enter the id of the student to update: ");
					int sidupdate = s.nextInt();
					studentdaoimpl.updateStudentData(sidupdate);
					break;
				case 8:
					System.out.println("Enter the id of the student to delete:");
					int siddelete = s.nextInt();
					studentdaoimpl.deleteStudentData(siddelete);
					break;
				case 9:
					System.exit(0);
					break;
				default:
					System.out.println("***Invalid Choice! Please try again");
					System.out.println("\n");
			}
		}	

	}

}
