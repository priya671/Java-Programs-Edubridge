package com.cap.cl.main;

/**
 * all copy rights reserved to user priya kothare
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cap.cl.pojo.Student;

public class StudentInformation {
	//HashMap is used to store the user after registration(Key and value)
	Map<String,String> userslist = new HashMap<String,String>();
	//ArrayList is used to store student data
	List<Student> studentlist = new ArrayList<Student>();

	//validating user after registration
	public String validateUser(String username, String password) {
		for(Entry<String,String> entry:userslist.entrySet()) {
			if(entry.getKey().equalsIgnoreCase(username) && entry.getValue().equals(password)) {
				return entry.getKey();
			}
		}
		return null;
	}

	//Adding username and password in userlist HashMap after registration
	public void register(String username,String password) {
		userslist.put(username, password);
		//System.out.println(userslist);
	}
	
	//When called will store current student data
	public void StoreStudent(List<Student> studentinfo) {
		this.studentlist = studentinfo;
	}
	
	//Will return current studentlist
	public List<Student> getStudents(){
		return this.studentlist;
	}
	
	
//	public void getStudentsByIterator() {
//		Iterator<Student> iter = studentlist.iterator();
//		System.out.println("Student Id\t Student Name\t Student Course\t Student Balance\t Student Status");
//		while(iter.hasNext()) {
//			Student sob = iter.next();
//			System.out.println(sob.getStudentid()+ "\t" + sob.getStudentname() + "\t" + sob.getCourse() + "\t" + sob.getStudentbalance() + "\t" + sob.getStudentstatus());
//		}
//	}
	
	//getting student object with id as parameter
	public Student getStudentById(int sid) {
		for(Student s: studentlist) {
			if(s.getStudentid()==sid) { //if id exists then return student object
				return(s);
			}
		}
		return null;
	}
	
	//getting students of same status
	public List<Student> getStudentByStatus(String status) {
		//creating new list and adding students of same status in it
		List<Student> listbystatus = new ArrayList<Student>();
		System.out.println("******");
		System.out.println("Student Id\tStudent Name\t             Student Course\t   Student Balance\tStudent Status\tTution Fee Paid Amount");
		//Iterating through studentlist to get student of same status
		for(Student studentlist:studentlist) {
			if(studentlist.getStudentstatus().equalsIgnoreCase(status)) {
				listbystatus.add(studentlist);
				//printing studentlist of same status
				System.out.println(studentlist.getStudentid()+ "\t" + "\t" + studentlist.getStudentname() + "\t" + "\t         " + studentlist.getCourse()+ "\t" + "\t" + "\t"+ studentlist.getStudentbalance() + "\t" + "\t" + studentlist.getStudentstatus()
				+ "\t" + "\t" + studentlist.getTutionfeestatus());
				//System.out.println(studentlist);
			}
		}
		//if no status matches return null
		if(listbystatus.size()==0)
			//System.out.println("No data found");
			return null;
		return listbystatus;
	}

}
