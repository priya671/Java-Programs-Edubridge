package com.cap.cl.dao;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cap.cl.database.DatabaseConnection;
import com.cap.cl.main.StudentInformation;

/**
 * all copy rights reserved to user priya kothare
 */


public class StudentDAOImpl implements StudentDAO{
	
	//creating studentinformation object to access methods
	StudentInformation studentinformation;
	BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
	//to generate unique id
//	int max = 99999;
//	int min = 10000;
	
	private static Connection conn;
	private static PreparedStatement pst;
	private static ResultSet rs;
	static {
		try {//creating common connection
			conn = DatabaseConnection.getDatabaseConnection(); 
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	

	public StudentDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentDAOImpl(StudentInformation studentinformation) {
		super();
		this.studentinformation = studentinformation;
	}


	//View Student Balance By Id and password
	public void viewStudentBalance(int id,String password) throws Exception {
		System.out.println("************");
	try {
		String sel = "select * from studentlist where id=? and password=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		pst.setString(2, password);
		rs = pst.executeQuery();
			if(rs.next()) {
				System.out.println(rs.getString("name") + "'s balance= " + rs.getInt("balance"));
			}
			else {
				System.out.println("No Student found with mentioned Id");
			}

		}
		catch(Exception e) {
			System.out.println(e);
			//System.out.println("Exception: No Student found with mentioned Id");
		}
		
		System.out.println("************");
		
	}

	public void payStudentFees(int id,String password) throws SQLException {
		System.out.println("************");
		try {
			String sel = "select * from studentlist where id=? and password=?";
			pst = conn.prepareStatement(sel);
			pst.setInt(1, id);
			pst.setString(2, password);
			rs = pst.executeQuery();
		
			if(rs.next()) {
					System.out.println("Available Student Balance: " + rs.getDouble("balance"));
					System.out.println("Enter the tution fee amount to pay: ");
					int amt = Integer.parseInt(bfr.readLine());
					
					if(rs.getDouble("balance")==0) { //Check if the balance is 0
						System.out.println("There is no pending student fees. All the Tution Fee is Paid Successfully!");
					}
					else if(amt>rs.getDouble("balance")) { //Check if amount is greater than balance
						System.out.println("Insufficient Balance!");
					}
					else if(amt<=0) { //Check if amount is negative or 0
						System.out.println("Invalid Amount. Please try again!");
					}
					else { //Pay the fees if the above conditions are false
						double available_amount = (rs.getDouble("balance")-amt);
						System.out.println("Available balance: " + available_amount);
						String upd = "update studentlist set balance=?,fees_paid=? where id=?";
						pst = conn.prepareStatement(upd);
						pst.setDouble(1, available_amount);
						double g = rs.getDouble("fees_paid");
						pst.setDouble(2, g+amt);
						pst.setInt(3, id);
						int r = pst.executeUpdate();
						if(r>0) {
							System.out.println(amt + " paid successfully!");
						}
					}
				}
			else {
				System.out.println("No student found with mentioned Id");
			}
				
		}catch(Exception e) { //if Student object is null it will invoke catch block
			System.out.println(e);	
	}
		System.out.println("************");
		
	}

	//Get all student information by id and password
	public void getStudentInfoById(int id,String password) throws SQLException {
		System.out.println("************");
		try {
		String sel = "select * from studentlist where id=? and password=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		pst.setString(2, password);
		rs = pst.executeQuery();
		if(rs.next()) {
			System.out.println("+----------------------------------------------------------------------------------------------------------------------------------------------------+");
			System.out.printf("%-20s %-20s     %-20s     %-20s %-20s %-15s %-20s\n","Student Id","Student Name","Student Course","Student Balance","Student Status","Fee Paid","Password");
			System.out.println("+----------------------------------------------------------------------------------------------------------------------------------------------------+");
			System.out.printf("%-20d %-20s     %-20s     %-20s %-20s %-15s %-20s\n",rs.getInt("id"),rs.getString("name"),rs.getString("course"),rs.getDouble("balance"),rs.getString("status"),rs.getDouble("fees_paid"),rs.getString("password"));
			System.out.println("+----------------------------------------------------------------------------------------------------------------------------------------------------+");
			System.out.println("+----------------------------------------------------------------------------------------------------------------------------------------------------+");
		}
		else {
			System.out.println("No student found with mentioned id");
		}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("************");
		
	}
	
	//Get student paid fee by id and password
	public void getStudentfeeById(int id, String password) throws SQLException {
		System.out.println("**********");
		try {
		String sel = "select * from studentlist where id=? and password=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		pst.setString(2, password);
		rs = pst.executeQuery();
		if(rs.next()) {
			System.out.println("Tution Fee paid by " + rs.getString("name") + " is " + rs.getDouble("fees_paid"));
		}
		else {
			System.out.println("No Student found by mentioned Id");
		}
		}catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("************");
	}
	
	//Change Student Password by id and password
	public void changeStudentPassword(int id,String password) throws SQLException {
		System.out.println("*************");
		try {
			String sel = "select * from studentlist where id=? and password=?";
			pst = conn.prepareStatement(sel);
			pst.setInt(1, id);
			pst.setString(2, password);
			rs = pst.executeQuery();
			if(rs.next()) {
				System.out.println(rs.getString("name") + "'s old password: " + rs.getString("password"));
				System.out.println("Enter new Password: ");
				String pass = bfr.readLine();
				String updpass = "update studentlist set password=? where id=?";
				pst = conn.prepareStatement(updpass);
				pst.setString(1, pass);
				pst.setInt(2, id);
				int r = pst.executeUpdate();
				if(r>0) {
					System.out.println("Password updated successfully!");
				}
			}
			else {
				System.out.println("No Student found by mentioned Id");
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("****************");
	}


}
